import React from 'react'

const SingleMovie = () => {
  return (
    <div>SingleMovie</div>
  )
}

export default SingleMovie