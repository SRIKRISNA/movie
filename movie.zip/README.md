<!-- run json server first -->
npx json-server --watch db.json --port 3005

<!-- now open another terminal -->
npm start 

